import React from 'react';

const NotFound = () => {
    return (
        <div>
            404 Pages not found
        </div>
    );
};

export default NotFound;